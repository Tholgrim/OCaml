open Graphics ;; open Random;;
open_graph "";;

let rec mountain x y z t = function
	| 0 -> moveto x y; lineto z t
	| n -> 
		let h = (y+t)/2 + int(abs(z-x)/5 + 20) and u = x+(z-x)/2 in
				mountain x y u h (n-1);
				mountain u h z t (n-1);;

let rec dragon x y z t = function
  | 0 -> (moveto x y; lineto z t)
  | n -> let m = (z+x)/2+(t-y)/2 and h = (y+t)/2-(z-x)/2 in
      dragon x y m h (n-1);
      dragon z t m h (n-1) ;;

let eponge (x,y) n =
  moveto x y;
  set_color black;
  fill_rect x y n n;
  set_color white; 
  let rec sierpinsky (x,y) n = function
    | 0 -> ()
    | p -> let n3 = (n/3) in
      let x1 = x+n3 and x2 = x + 2*n3 and y1 = y + n3 and y2 = y + 2*n3
      in
      fill_rect x1 y1 n3 n3;
      sierpinsky (x,y) n3 (p-1);
      sierpinsky (x1,y) n3 (p-1);
      sierpinsky (x2,y) n3 (p-1);
      sierpinsky (x,y1) n3 (p-1);
      sierpinsky (x2,y1) n3 (p-1);
      sierpinsky (x,y2) n3 (p-1);
      sierpinsky (x1,y2) n3 (p-1);
      sierpinsky (x2,y2) n3 (p-1)
  in sierpinsky (x,y) n 5;;

let rec koch (x1, y1) (x5, y5) = function
  | 0 -> (moveto x1 y1; lineto x5 y5)
  | n ->
	let x2 = x1 + (x5 - x1) / 3 and y2 = y1 + (y5 - y1) / 3 in
	let x4 = x1 + 2 * (x5 - x1) / 3 and y4 = y1 + 2 * (y5 - y1) / 3 in
	let x3 = (x2 + x4) / 2 - int_of_float(float_of_int(y4 - y2) *. sqrt 3. /. 2.)
	and y3 = (y2 + y4) / 2 + int_of_float(float_of_int(x4 - x2) *. sqrt 3. /. 2.) in
	koch (x1, y1) (x2, y2) (n - 1);
	koch (x2, y2) (x3, y3) (n - 1);
	koch (x3, y3) (x4, y4) (n - 1);
	koch (x4, y4) (x5, y5) (n - 1);;
		
let flocon (x1,y1) (x2,y2) n =
	let x3 = (x1 + x2) / 2 - int_of_float(float_of_int(y2 - y1) *. sqrt 3. /. 2.)
	and y3 = (y1 + y2) / 2 - int_of_float(float_of_int(x2 - x1) *. sqrt 3. /. 2.) in
	koch (x1, y1) (x2, y2) n;
	koch (x2, y2) (x3, y3) n;
	koch (x3, y3) (x1, y1) n;;
